#include <iostream>
using namespace std;

int main() {
    int wow = 11;
    cout << wow << endl;
    cout << "wow" << endl;
    cout << wow * 4 << endl;
    cout << wow / 4 << endl;
    cout << wow % 4 << endl;
}