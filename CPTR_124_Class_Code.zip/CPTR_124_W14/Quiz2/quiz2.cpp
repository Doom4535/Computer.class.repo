#include <iostream>

using namespace std;

int main() {
    int x = 200;
    cout << x << endl;
    cout << "x" << endl;
}