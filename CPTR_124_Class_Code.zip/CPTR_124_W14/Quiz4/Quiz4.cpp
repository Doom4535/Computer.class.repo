#include <iostream>
using namespace std;

int main() {
    int i = 5;
    double d = 5;
    cout << i / 4 << endl;
    cout << d / 4 << endl;
    // cout << i + d << endl;
    cout << "(" << i << ")";
    cout << "[" << d << "]" << endl;
}