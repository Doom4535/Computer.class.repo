#include <iostream>

using namespace std;

int main() {
    int x;

    x = 2;
    cout << x << endl;
}
