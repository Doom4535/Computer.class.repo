#include <iostream>

using namespace std;

int main() {
    cout << "This is our first program" << endl;
}
